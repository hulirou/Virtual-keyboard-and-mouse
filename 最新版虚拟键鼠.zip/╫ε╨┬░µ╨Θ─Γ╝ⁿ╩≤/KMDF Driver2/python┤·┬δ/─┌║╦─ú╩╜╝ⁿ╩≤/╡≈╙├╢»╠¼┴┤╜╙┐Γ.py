import ctypes
from ctypes import c_char_p, POINTER
import time


# 加载DLL
huli_gamepad = ctypes.CDLL("./huli_gamepad.dll")
# 初始化
huli_gamepad.init()


# 文本输入
# huli_gamepad.typewrite(b"aADAD{", 50)
# # 键盘按下并释放
# huli_gamepad.keyboardPressAndRelease(b"5", 50)
# # 键盘按下A键1秒后释放
# huli_gamepad.keyboardPress(b"a")
# time.sleep(1)
# huli_gamepad.keyboardPress(b"a")
# # 相对移动鼠标(x和y轴-127~127)
# huli_gamepad.mouseMove(123,123)
# # 绝对移动-触摸屏方式(x和y轴0~65535)
# huli_gamepad.mouseMove(40000,40000)
# 鼠标点击(左中右侧键1侧键2)
huli_gamepad.mouseClick(b"left")
# 鼠标按下和释放
huli_gamepad.mousePress(b"left")
huli_gamepad.mouseRelease(b"left")

# 鼠标滚轮(范围-127~127)
# huli_gamepad.mouseWheel(-120)









# 将Python字符串列表转换为C字符串数组(太鸡肋建议直接键盘按下后释放)
# test_args = ["shift", "win", "s"]
# c_args = (c_char_p * len(test_args))(*[arg.encode('utf-8') for arg in test_args])
# # 执行组合按键，同样键盘按键按下不得超过6个
# huli_gamepad.hotkey(c_args)









