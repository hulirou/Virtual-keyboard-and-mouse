import pyautogui
import ctypes
import time


# 鼠标缓缓相对移动（米基单位）
def move_mouse_by_mickeys(x_mickeys, y_mickeys):
    # 四舍五入为整数
    total_x = int(round(x_mickeys))
    total_y = int(round(y_mickeys))

    # 计算需要移动的步数和每步移动距离
    remaining_x = total_x
    remaining_y = total_y

    # 每次移动1单位，直到剩余距离为0
    while remaining_x != 0 or remaining_y != 0:
        # 计算当前步的移动距离，每次1单位
        step_x = 1 if remaining_x > 0 else -1 if remaining_x < 0 else 0
        step_y = 1 if remaining_y > 0 else -1 if remaining_y < 0 else 0

        # 发送鼠标移动指令
        huli_gamepad.mouseMove(step_x, step_y)

        # 更新剩余距离
        remaining_x -= step_x
        remaining_y -= step_y
        time.sleep(0.001)


# 内核模式只能米基（Mickey）和原始计数（Counts）,用户模式可以直接传递像素由api计算多少米基,但是基本上都会被拦截
# 计算1像素是多少米基
def get_mickey_per_pixel():
    time.sleep(2)
    # 移动到初始位置(0, 0)
    pyautogui.moveTo(0, 0)
    time.sleep(1)
    # 虚拟鼠标移动
    move_mouse_by_mickeys(160, 0)

    time.sleep(3)

    # 获取当前位置并提取x坐标
    current_position = pyautogui.position()
    current_x = current_position.x  # 从Point对象中获取x坐标值

    # 计算米基与像素的比例
    mickey_per_pixel = 160 / current_x
    print(f"1像素约等于{mickey_per_pixel:.2f}个米基")
    return mickey_per_pixel

# 计算1像素是多少逻辑单位
def get_mickey_per_LogicalUnits():
    time.sleep(2)
    # 移动到初始位置(0, 0)
    pyautogui.moveTo(0, 0)
    time.sleep(1)
    # 虚拟鼠标移动
    huli_gamepad.mouseMoveTo(160, 0)

    time.sleep(3)

    # 获取当前位置并提取x坐标
    current_position = pyautogui.position()
    current_x = current_position.x  # 从Point对象中获取x坐标值

    # 计算米基与像素的比例
    mickey_per_pixel = 160 / current_x
    print(f"1像素约等于{mickey_per_pixel:.2f}个逻辑单位")
    return mickey_per_pixel



# 加载DLL
huli_gamepad = ctypes.CDLL("./huli_gamepad.dll")  # 注意路径正确性
# 获取设备句柄，我们的设备输入报告交给这个设备
hDevice = huli_gamepad.init()
# 获取1像素是多少米基和逻辑单位
mickey_per_pixel = get_mickey_per_pixel()
mickey_per_LogicalUnits = get_mickey_per_LogicalUnits()
