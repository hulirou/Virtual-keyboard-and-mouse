#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <initguid.h>
#include <SetupAPI.h>
#include <iostream>
#pragma comment(lib, "setupapi.lib")


//���е�С��������c��ɣ��ܶණ���ں˶�û���ã��ں�ģʽֻ����յ�HID���뱨�淢�͡�




//��������루�е���൫�޷���
#define IOCTL_TEST CTL_CODE(FILE_DEVICE_UNKNOWN, 0X800, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_Keyboard CTL_CODE(FILE_DEVICE_UNKNOWN, 0X801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_Mouse CTL_CODE(FILE_DEVICE_UNKNOWN, 0X802, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_TouchScreen CTL_CODE(FILE_DEVICE_UNKNOWN, 0X803, METHOD_BUFFERED, FILE_ANY_ACCESS)

// {685186F1-995E-40E4-BDD4-184723D15E94}
DEFINE_GUID(DEVICEINTERFACE,
    0x685186f1, 0x995e, 0x40e4, 0xbd, 0xd4, 0x18, 0x47, 0x23, 0xd1, 0x5e, 0x94);





//ֱ����Queue.h���ù�����,���ֶ���һ��
//����������뱨��
typedef struct _KEYBOARD_INPUT_REPORT
{
    uint8_t ReportId;  // ����ID
    uint8_t Modifiers;    // ���μ�λͼ,Shift��Ctrl��Alt �����μ���״̬(������ܿ���ͬʱ���¶�������Ǻ���ͨ�������벻ͬ)
    uint8_t Reserved;     // �����ֽ�
    uint8_t ScanCodes[6]; // �洢ͬʱ���µİ���ɨ����(֧����� 6 ������ͬʱ����)
} KEYBOARD_INPUT_REPORT, * PKEYBOARD_INPUT_REPORT;

//����������뱨��
typedef struct _MOUSE_INPUT_REPORT
{
    uint8_t ReportId;       // ����ID
    uint8_t Buttons;        // ����
    char DeltaX;            // x��
    char DeltaY;            // y��
    char WheelDelta;        // ����
} MOUSE_INPUT_REPORT, * PMOUSE_INPUT_REPORT;

//���崥�������뱨��
typedef struct _TOUCHSCREEN_INPUT_REPORT
{
    uint8_t ReportId;           // ����ID
    uint8_t Buttons;            // ����״̬ (bit0-bit4��Ӧ5��������bit5-bit7Ϊ���λ)
    uint16_t DeltaX;            // X�����λ�ƣ�0~1023��2�ֽڣ�
    uint16_t DeltaY;            // Y�����λ�ƣ�0~1023��2�ֽڣ�
} TOUCHSCREEN_INPUT_REPORT, * PTOUCHSCREEN_INPUT_REPORT;









//��ȡ�豸��λ�ú���
PTSTR GetDevicePath() {
    HDEVINFO hInfo = SetupDiGetClassDevs(&DEVICEINTERFACE, NULL, NULL, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);

    if (hInfo == NULL) {
        return NULL;
    }


    SP_DEVICE_INTERFACE_DATA ifdata = { 0 };
    ifdata.cbSize = sizeof(ifdata);
    if (!SetupDiEnumDeviceInterfaces(hInfo, NULL, &DEVICEINTERFACE, 0, &ifdata)) {
        printf("ö�ٽӿ�ʧ��%d\n", GetLastError());
        return NULL;
    }

    PSP_DEVICE_INTERFACE_DETAIL_DATA pdetailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(1024);
    DWORD dwSize = 0;
    RtlZeroMemory(pdetailData, 1024);
    pdetailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
    if (!SetupDiGetDeviceInterfaceDetail(hInfo, &ifdata, pdetailData, 1024, &dwSize, NULL))
    {
        return NULL;
    }
    else
    {
        return pdetailData->DevicePath;
    }
}


//���ͼ��̱��浽��������
bool sendKeyboardReportToDriver(HANDLE hDevice, KEYBOARD_INPUT_REPORT sendData) {
    DWORD dwret;
    char outBuffer[1024] = { 0 };

    // �������ݵ��豸
    BOOL success = DeviceIoControl(
        hDevice,
        IOCTL_Keyboard,
        &sendData,
        sizeof(sendData),
        outBuffer,
        sizeof(outBuffer),
        &dwret,
        NULL
    );
    if (!success) {
        return false;
    }
    else {
        return true;
    }
}
//������걨�浽��������
bool sendMouseReportToDriver(HANDLE hDevice, MOUSE_INPUT_REPORT sendData) {
    DWORD dwret;
    char outBuffer[1024] = { 0 };

    // �������ݵ��豸
    BOOL success = DeviceIoControl(
        hDevice,
        IOCTL_Mouse,
        &sendData,
        sizeof(sendData),
        outBuffer,
        sizeof(outBuffer),
        &dwret,
        NULL
    );
    if (!success) {
        printf("�������ݵ�����ʧ��: %d\n", GetLastError());
        return false;
    }
    else {
        return true;
    }
}
//���ʹ��������浽��������
bool sendTouchScreenReportToDriver(HANDLE hDevice, TOUCHSCREEN_INPUT_REPORT sendData) {
    DWORD dwret;
    char outBuffer[1024] = { 0 };

    // �������ݵ��豸
    BOOL success = DeviceIoControl(
        hDevice,
        IOCTL_TouchScreen,
        &sendData,
        sizeof(sendData),
        outBuffer,
        sizeof(outBuffer),
        &dwret,
        NULL
    );
    if (!success) {
        printf("�������ݵ�����ʧ��: %d\n", GetLastError());
        return false;
    }
    else {
        return true;
    }
}




// ���巵�ؽṹ�壬����������Ƿ�Ϊ��д�ı�־
typedef struct {
    uint8_t keyCode;    // ��ֵ��
    uint8_t isBig;      // ��Сд��־��0x00=Сд��0x02=��д
} KeyInfo;

KeyInfo buttonToKeyCode(const char* keyStr) {
    // ��ʼ������ֵ��Ĭ��Ϊ�ռ�����Сд��isBig=0x00��
    KeyInfo result = { 0x00, 0x00 };

    // �������ַ���������ĸ�����֡����ţ�
    if (strlen(keyStr) == 1) {
        char c = keyStr[0];
        switch (c) {
            // ��ĸ�������ִ�Сд��isBig=0x02Ϊ��д��0x00ΪСд��
        case 'A':
            result.keyCode = 0x04;
            result.isBig = 0x02;
            return result;
        case 'a':
            result.keyCode = 0x04;
            result.isBig = 0x00;
            return result;
        case 'B':
            result.keyCode = 0x05;
            result.isBig = 0x02;
            return result;
        case 'b':
            result.keyCode = 0x05;
            result.isBig = 0x00;
            return result;
        case 'C':
            result.keyCode = 0x06;
            result.isBig = 0x02;
            return result;
        case 'c':
            result.keyCode = 0x06;
            result.isBig = 0x00;
            return result;
        case 'D':
            result.keyCode = 0x07;
            result.isBig = 0x02;
            return result;
        case 'd':
            result.keyCode = 0x07;
            result.isBig = 0x00;
            return result;
        case 'E':
            result.keyCode = 0x08;
            result.isBig = 0x02;
            return result;
        case 'e':
            result.keyCode = 0x08;
            result.isBig = 0x00;
            return result;
        case 'F':
            result.keyCode = 0x09;
            result.isBig = 0x02;
            return result;
        case 'f':
            result.keyCode = 0x09;
            result.isBig = 0x00;
            return result;
        case 'G':
            result.keyCode = 0x0A;
            result.isBig = 0x02;
            return result;
        case 'g':
            result.keyCode = 0x0A;
            result.isBig = 0x00;
            return result;
        case 'H':
            result.keyCode = 0x0B;
            result.isBig = 0x02;
            return result;
        case 'h':
            result.keyCode = 0x0B;
            result.isBig = 0x00;
            return result;
        case 'I':
            result.keyCode = 0x0C;
            result.isBig = 0x02;
            return result;
        case 'i':
            result.keyCode = 0x0C;
            result.isBig = 0x00;
            return result;
        case 'J':
            result.keyCode = 0x0D;
            result.isBig = 0x02;
            return result;
        case 'j':
            result.keyCode = 0x0D;
            result.isBig = 0x00;
            return result;
        case 'K':
            result.keyCode = 0x0E;
            result.isBig = 0x02;
            return result;
        case 'k':
            result.keyCode = 0x0E;
            result.isBig = 0x00;
            return result;
        case 'L':
            result.keyCode = 0x0F;
            result.isBig = 0x02;
            return result;
        case 'l':
            result.keyCode = 0x0F;
            result.isBig = 0x00;
            return result;
        case 'M':
            result.keyCode = 0x10;
            result.isBig = 0x02;
            return result;
        case 'm':
            result.keyCode = 0x10;
            result.isBig = 0x00;
            return result;
        case 'N':
            result.keyCode = 0x11;
            result.isBig = 0x02;
            return result;
        case 'n':
            result.keyCode = 0x11;
            result.isBig = 0x00;
            return result;
        case 'O':
            result.keyCode = 0x12;
            result.isBig = 0x02;
            return result;
        case 'o':
            result.keyCode = 0x12;
            result.isBig = 0x00;
            return result;
        case 'P':
            result.keyCode = 0x13;
            result.isBig = 0x02;
            return result;
        case 'p':
            result.keyCode = 0x13;
            result.isBig = 0x00;
            return result;
        case 'Q':
            result.keyCode = 0x14;
            result.isBig = 0x02;
            return result;
        case 'q':
            result.keyCode = 0x14;
            result.isBig = 0x00;
            return result;
        case 'R':
            result.keyCode = 0x15;
            result.isBig = 0x02;
            return result;
        case 'r':
            result.keyCode = 0x15;
            result.isBig = 0x00;
            return result;
        case 'S':
            result.keyCode = 0x16;
            result.isBig = 0x02;
            return result;
        case 's':
            result.keyCode = 0x16;
            result.isBig = 0x00;
            return result;
        case 'T':
            result.keyCode = 0x17;
            result.isBig = 0x02;
            return result;
        case 't':
            result.keyCode = 0x17;
            result.isBig = 0x00;
            return result;
        case 'U':
            result.keyCode = 0x18;
            result.isBig = 0x02;
            return result;
        case 'u':
            result.keyCode = 0x18;
            result.isBig = 0x00;
            return result;
        case 'V':
            result.keyCode = 0x19;
            result.isBig = 0x02;
            return result;
        case 'v':
            result.keyCode = 0x19;
            result.isBig = 0x00;
            return result;
        case 'W':
            result.keyCode = 0x1A;
            result.isBig = 0x02;
            return result;
        case 'w':
            result.keyCode = 0x1A;
            result.isBig = 0x00;
            return result;
        case 'X':
            result.keyCode = 0x1B;
            result.isBig = 0x02;
            return result;
        case 'x':
            result.keyCode = 0x1B;
            result.isBig = 0x00;
            return result;
        case 'Y':
            result.keyCode = 0x1C;
            result.isBig = 0x02;
            return result;
        case 'y':
            result.keyCode = 0x1C;
            result.isBig = 0x00;
            return result;
        case 'Z':
            result.keyCode = 0x1D;
            result.isBig = 0x02;
            return result;
        case 'z':
            result.keyCode = 0x1D;
            result.isBig = 0x00;
            return result;

        // ���ּ�������������- ���ֳ����Shift״̬��isBig��
        case '1':
            result.keyCode = 0x1E;
            return result;
        case '!':  // 1��Shift״̬
            result.keyCode = 0x1E;
            result.isBig = 0x02;
            return result;
        case '2':
            result.keyCode = 0x1F;
            return result;
        case '@':  // 2��Shift״̬
            result.keyCode = 0x1F;
            result.isBig = 0x02;
            return result;
        case '3':
            result.keyCode = 0x20;
            return result;
        case '#':  // 3��Shift״̬
            result.keyCode = 0x20;
            result.isBig = 0x02;
            return result;
        case '4':
            result.keyCode = 0x21;
            return result;
        case '$':  // 4��Shift״̬
            result.keyCode = 0x21;
            result.isBig = 0x02;
            return result;
        case '5':
            result.keyCode = 0x22;
            return result;
        case '%':  // 5��Shift״̬
            result.keyCode = 0x22;
            result.isBig = 0x02;
            return result;
        case '6':
            result.keyCode = 0x23;
            return result;
        case '^':  // 6��Shift״̬
            result.keyCode = 0x23;
            result.isBig = 0x02;
            return result;
        case '7':
            result.keyCode = 0x24;
            return result;
        case '&':  // 7��Shift״̬
            result.keyCode = 0x24;
            result.isBig = 0x02;
            return result;
        case '8':
            result.keyCode = 0x25;
            return result;
        case '*':  // 8��Shift״̬
            result.keyCode = 0x25;
            result.isBig = 0x02;
            return result;
        case '9':
            result.keyCode = 0x26;
            return result;
        case '(':  // 9��Shift״̬
            result.keyCode = 0x26;
            result.isBig = 0x02;
            return result;
        case '0':
            result.keyCode = 0x27;
            return result;
        case ')':  // 0��Shift״̬
            result.keyCode = 0x27;
            result.isBig = 0x02;
            return result;

        // ���ż�������������- ���ֳ����Shift״̬��isBig��
        case '-':
            result.keyCode = 0x2D;
            return result;
        case '_':
            result.keyCode = 0x2D;
            result.isBig = 0x02;
            return result;
        case '=':
            result.keyCode = 0x2E;
            return result;
        case '+':
            result.keyCode = 0x2E;
            result.isBig = 0x02;
            return result;
        case '[':
            result.keyCode = 0x2F; // ���������ż�ֵ��
            return result;
        case '{':
            result.keyCode = 0x2F; // ���������ż�ֵ��
            result.isBig = 0x02;
            return result;
        case ']':
            result.keyCode = 0x30; // �����ҷ����ż�ֵ��
            return result;
        case '}':
            result.keyCode = 0x30; // �����һ����ż�ֵ��
            result.isBig = 0x02;
            return result;
        case '\\':
            result.keyCode = 0x32;
            return result;
        case '|':
            result.keyCode = 0x32;
            result.isBig = 0x02;
            return result;
        case ';':
            result.keyCode = 0x33;
            return result;
        case ':':
            result.keyCode = 0x33;
            result.isBig = 0x02;
            return result;
        case '\'':
            result.keyCode = 0x34;
            return result;
        case '"':
            result.keyCode = 0x34;
            result.isBig = 0x02;
            return result;
        case '`':
            result.keyCode = 0x35;
            return result;
        case '~':
            result.keyCode = 0x35;
            result.isBig = 0x02;
            return result;
        case ',':
            result.keyCode = 0x36;
            return result;
        case '<':
            result.keyCode = 0x36;
            result.isBig = 0x02;
            return result;
        case '.':
            result.keyCode = 0x37;
            return result;
        case '>':
            result.keyCode = 0x37;
            result.isBig = 0x02;
            return result;
        case '/':
            result.keyCode = 0x38;
            return result;
        case '?':
            result.keyCode = 0x38;
            result.isBig = 0x02;
            return result;

        default:
            return result;  // δ֪���ַ�������Ĭ��ֵ
        }


    }
    // �������ַ���������޴�Сд��isBig����0x00��
    else {
        if (_stricmp(keyStr, "Tab") == 0)
            result.keyCode = 0x0F;
        else if (_stricmp(keyStr, "Enter") == 0)
            result.keyCode = 0x1C;
        else if (_stricmp(keyStr, "Escape") == 0)
            result.keyCode = 0x01;
        else if (_stricmp(keyStr, "Backspace") == 0)
            result.keyCode = 0x0E;
        else if (_stricmp(keyStr, "Space") == 0)
            result.keyCode = 0x39;
        else if (_stricmp(keyStr, "Shift") == 0)
            result.keyCode = 0x02;
        else if (_stricmp(keyStr, "Ctrl") == 0)
            result.keyCode = 0x1D;
        else if (_stricmp(keyStr, "Alt") == 0)
            result.keyCode = 0x38;
        else if (_stricmp(keyStr, "F1") == 0)
            result.keyCode = 0x3B;
        else if (_stricmp(keyStr, "F2") == 0)
            result.keyCode = 0x3C;
        else if (_stricmp(keyStr, "F3") == 0)
            result.keyCode = 0x3D;
        else if (_stricmp(keyStr, "F4") == 0)
            result.keyCode = 0x3E;
        else if (_stricmp(keyStr, "F5") == 0)
            result.keyCode = 0x3F;
        else if (_stricmp(keyStr, "F6") == 0)
            result.keyCode = 0x40;
        else if (_stricmp(keyStr, "F7") == 0)
            result.keyCode = 0x41;
        else if (_stricmp(keyStr, "F8") == 0)
            result.keyCode = 0x42;
        else if (_stricmp(keyStr, "F9") == 0)
            result.keyCode = 0x43;
        else if (_stricmp(keyStr, "F10") == 0)
            result.keyCode = 0x44;
        else if (_stricmp(keyStr, "F11") == 0)
            result.keyCode = 0x57;
        else if (_stricmp(keyStr, "F12") == 0)
            result.keyCode = 0x58;
        else if (_stricmp(keyStr, "Insert") == 0)
            result.keyCode = 0xD2;
        else if (_stricmp(keyStr, "Delete") == 0)
            result.keyCode = 0xD3;
        else if (_stricmp(keyStr, "Home") == 0)
            result.keyCode = 0xC7;
        else if (_stricmp(keyStr, "End") == 0)
            result.keyCode = 0xCF;
        else if (_stricmp(keyStr, "PageUp") == 0)
            result.keyCode = 0xC9;
        else if (_stricmp(keyStr, "PageDown") == 0)
            result.keyCode = 0xD1;
        else if (_stricmp(keyStr, "Up") == 0)
            result.keyCode = 0xC8;
        else if (_stricmp(keyStr, "Down") == 0)
            result.keyCode = 0xD0;
        else if (_stricmp(keyStr, "Left") == 0)
            result.keyCode = 0xCB;
        else if (_stricmp(keyStr, "Right") == 0)
            result.keyCode = 0xCD;
        else if (_stricmp(keyStr, "Null") == 0)
            result.keyCode = 0x00;

        return result;
    }
}


//���̰���
bool keyboardPress(HANDLE hDevice, uint8_t KeyCodes, uint8_t Modifiers) {
    KEYBOARD_INPUT_REPORT keyboardData = { 0 };
    keyboardData.ReportId = 1;
    keyboardData.ScanCodes[0] = KeyCodes;
    keyboardData.Modifiers = Modifiers;

    if (!sendKeyboardReportToDriver(hDevice, keyboardData)) {
        return false;
    }
}
//�����ͷ�
bool keyboardRelease(HANDLE hDevice, uint8_t KeyCodes, uint8_t Modifiers) {
    KEYBOARD_INPUT_REPORT keyboardData = { 0 };
    keyboardData.ReportId = 1;
    keyboardData.ScanCodes[0] = 0x00;
    keyboardData.Modifiers = 0x00;

    if (!sendKeyboardReportToDriver(hDevice, keyboardData)) {
        return false;
    }
}

//���¼��̺��ͷź���
bool keyboardPressAndRelease(HANDLE hDevice, uint8_t KeyCodes, uint8_t Modifiers, int time_ms) {
    bool success=keyboardPress(hDevice, KeyCodes, Modifiers);
    if (!success) {
        printf("���ͼ������뱨��ʧ��\n");
        return false;
    }

    Sleep(time_ms);

    success = keyboardRelease(hDevice, KeyCodes, Modifiers);
    if (!success) {
        printf("���ͼ������뱨��ʧ��\n");
        return false;
    }

    return true;
}

//�����ı�
bool typewrite(HANDLE hDevice, const char* keyStr,int time_ms) {
    int strLen = strlen(keyStr);
    if (strLen == 0|| keyStr == NULL) {
        printf("�����ַ���Ϊ��\n");
        return false;
    }

    for (int i = 0; i < strLen; i++) {
        char currentChar = keyStr[i];
        char singleChar[2] = { currentChar, '\0' };
        KeyInfo keyInfo = buttonToKeyCode(singleChar);

        if (keyInfo.keyCode == 0x00) {
            printf("����δ֪�ַ� '%c'���������ַ�\n", currentChar);
            continue;
        }
        else {
            printf("��: '%c'����ֵ��: 0x%02X\n", currentChar, keyInfo.keyCode);
            //ֻ����15����
            keyboardPressAndRelease(hDevice, keyInfo.keyCode, keyInfo.isBig, 5);
        }

        if (time_ms > 0) {
            Sleep(time_ms);
        }

    }
    return true;
}



//����ƶ����
bool mouseMove(HANDLE hDevice, uint8_t buttonFlags, char deltaX, char deltaY, char wheelDelta) {

    MOUSE_INPUT_REPORT mouseData = { 0 };
    mouseData.ReportId = 2;
    mouseData.Buttons = buttonFlags;
    mouseData.DeltaX = deltaX;
    mouseData.DeltaY = deltaY;
    mouseData.WheelDelta = wheelDelta;

    if (!sendMouseReportToDriver(hDevice, mouseData)) {
        return false;
    }
    return true;
}


//�����ƶ����
bool mouseMoveTo(HANDLE hDevice, uint8_t buttonFlags, uint16_t deltaX, uint16_t deltaY) {

    TOUCHSCREEN_INPUT_REPORT touchScreenData = { 0 };
    touchScreenData.ReportId = 3;
    touchScreenData.Buttons = buttonFlags;
    touchScreenData.DeltaX = deltaX;
    touchScreenData.DeltaY = deltaY;

    if (!sendTouchScreenReportToDriver(hDevice, touchScreenData)) {
        return false;
    }
    return true;
}



bool mouseClick(HANDLE hDevice) {
    return true;
}
bool mouseWheel(HANDLE hDevice) {
    return true;
}

//��·
void runrunrun() {
    printf("���򼴽�2����ӳ����죡\n");
    Sleep(2);
    printf("run��\n");
}


int main() {
    LPTSTR DevicePath = NULL;
    if ((DevicePath = GetDevicePath()) != NULL)
    {
        printf("�豸·��%ls\n", DevicePath);

        // ���豸���õ����
        HANDLE hDevice = CreateFile(DevicePath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_WRITE | FILE_SHARE_READ,
            NULL,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            NULL);

        if (hDevice == INVALID_HANDLE_VALUE)
        {
            printf("��ʧ��%d\n", GetLastError());
            return -1;
        }


        // ���ӳɹ���ѭ����ʾ�˵�
        while (TRUE)
        {
            // ��ʾ�����˵�
            printf("\n\n\n\n========== ������������Գ��� =========\n");
            printf("1. �����ı�\n");
            printf("2. ���²��ͷ�ָ������\n");
            printf("3. ����ָ������\n");
            printf("4. �ͷ�ָ������\n");

            printf("5. �������ƶ�\n");
            printf("6. �������ƶ�\n");
            printf("7. �����\n");
            printf("8. ���˫��\n");
            printf("9. ��갴��\n");
            printf("10. ����ͷ�\n");
            printf("11. ������\n");
            printf("0. �˳�\n");
            printf("========================================\n");
            printf("���в��������ӳ������ִ��\n");
            printf("��ѡ�����: ");

            // ��ȡ�û�ѡ��
            int choice;
            std::wcin >> choice;
            std::wcin.ignore(); // ������뻺����
            Sleep(2000);

            // ����ѡ��ִ����Ӧ����
            switch (choice) {
            case 1:
                if (typewrite(hDevice, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-=_[];'/.,?`!@#$%^&*()", 50)) {
                    printf("Ӣ���ַ��������!\n");
                }
                break;
            case 2:
                if (keyboardPressAndRelease(hDevice, 0x3C, 0x00, 100)) {
                    printf("��������1�����!\n");
                }
                break;
            case 3:
                if (keyboardPress(hDevice, 0x32, 0x00)) {
                    printf("�����������!\n");
                    Sleep(5000);
                    printf("���ͷŵĺ������һֱ��!���Զ��������а���̧��\n");
                    keyboardPress(hDevice, 0x00, 0x00);
                }
                break;
            case 4:
                if (keyboardPressAndRelease(hDevice, 0x04, 0x00, 1000)) {
                    printf("�����������!\n");
                }
                break;
            case 5:
                if (mouseMove(hDevice, 0, 120, 0, 0)) {
                    printf("�������ƶ����!\n");
                }
                break;
            case 6:
                if (mouseMoveTo(hDevice, 0, 1000, 0)) {
                    printf("�������ƶ����!\n");
                }
                break;
            case 7:
                break;
            case 8:
                break;
            case 9:
                break;
            case 10:
                break;
            case 11:
                break;
            case 0:
                runrunrun();
                CloseHandle(hDevice);
                return 0;
            default:
                printf("��Ч��ѡ��������!\n");
            }
        }
    }
    else
    {
        printf("�豸�ӿڻ�ȡʧ��: %d\n", GetLastError());
        runrunrun();
    }

    return 0;
}