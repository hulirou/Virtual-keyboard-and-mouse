import pyautogui
import ctypes
import time


# 鼠标缓缓相对移动（米基单位）
def move_mouse_by_mickeys(x_mickeys, y_mickeys):
    total_x = int(round(x_mickeys))
    total_y = int(round(y_mickeys))
    remaining_x = total_x
    remaining_y = total_y

    while remaining_x != 0 or remaining_y != 0:
        step_x = 1 if remaining_x > 0 else -1 if remaining_x < 0 else 0
        step_y = 1 if remaining_y > 0 else -1 if remaining_y < 0 else 0
        huli_gamepad.mouseMove(step_x, step_y)
        remaining_x -= step_x
        remaining_y -= step_y
        time.sleep(0.001)


# 分别计算X/Y轴 1像素对应的米基数
def get_mickey_per_pixel_xy():
    time.sleep(2)
    pyautogui.moveTo(0, 0)
    time.sleep(1)

    # 测试X轴米基比例
    test_mickey_x = 500
    move_mouse_by_mickeys(test_mickey_x, 0)
    time.sleep(1)
    current_x = pyautogui.position().x
    mickey_per_pixel_x = test_mickey_x / current_x if current_x != 0 else 0

    # 回到原点测试Y轴
    pyautogui.moveTo(0, 0)
    time.sleep(1)
    test_mickey_y = 500
    move_mouse_by_mickeys(0, test_mickey_y)
    time.sleep(1)
    current_y = pyautogui.position().y
    mickey_per_pixel_y = test_mickey_y / current_y if current_y != 0 else 0

    print(f"X轴: 1像素 ≈ {mickey_per_pixel_x:.2f} 米基")
    print(f"Y轴: 1像素 ≈ {mickey_per_pixel_y:.2f} 米基")
    return mickey_per_pixel_x, mickey_per_pixel_y


# 分别计算X/Y轴 1像素对应的逻辑单位数
def get_logical_units_per_pixel_xy():
    time.sleep(2)
    pyautogui.moveTo(0, 0)
    time.sleep(1)

    # 测试X轴逻辑单位比例
    test_logical_x = 10000
    huli_gamepad.mouseMoveTo(test_logical_x, 0)
    time.sleep(1)
    current_x = pyautogui.position().x
    logical_per_pixel_x = test_logical_x / current_x if current_x != 0 else 0

    # 回到原点测试Y轴
    pyautogui.moveTo(0, 0)
    time.sleep(1)
    test_logical_y = 10000
    huli_gamepad.mouseMoveTo(0, test_logical_y)
    time.sleep(1)
    current_y = pyautogui.position().y
    logical_per_pixel_y = test_logical_y / current_y if current_y != 0 else 0

    print(f"X轴: 1像素 ≈ {logical_per_pixel_x:.2f} 逻辑单位")
    print(f"Y轴: 1像素 ≈ {logical_per_pixel_y:.2f} 逻辑单位")
    return logical_per_pixel_x, logical_per_pixel_y


# 加载DLL并初始化设备
huli_gamepad = ctypes.CDLL("./huli_gamepad.dll")  # 确认DLL路径正确
hDevice = huli_gamepad.init()

# 执行比例计算（仅输出米基-像素、逻辑单位-像素的X/Y轴比例）
mickey_x_per_pixel, mickey_y_per_pixel = get_mickey_per_pixel_xy()
logical_x_per_pixel, logical_y_per_pixel = get_logical_units_per_pixel_xy()




# 该电脑
# X轴: 1像素 ≈ 1.60 米基
# Y轴: 1像素 ≈ 1.60 米基
# X轴: 1像素 ≈ 19.53 逻辑单位
# Y轴: 1像素 ≈ 31.25 逻辑单位