import ctypes
import threading
import time
import atexit
from ctypes import wintypes


# 映射结构体
class NEW_KEYBOARD_INFO(ctypes.Structure):
    _fields_ = [
        ("MakeCode", ctypes.c_uint8),  # 扫描码
        ("Button", wintypes.LPCWSTR),  # 按钮
        ("IsPress", wintypes.LPCWSTR)  # 是否按下
    ]


def exit_handler():
    print("程序即将退出，键盘鼠标全部释放...")
    keyboardPress(b"null")
    mousePress(b"null")

# 25延迟使用
def action1():
    mouseWheel(-2)
    # 太短了会无法蓄力
    time.sleep(0.01)
    mousePress(b"left")
    # 时间太短了也没法蓄力，可能是和延迟有关系（ps:用的好好的突然就完全用不了了）
    time.sleep(0.7)
    mousePress(b"null")

# 45延迟使用
def action2():
    mouseWheel(-2)
    # 太短了会无法蓄力
    time.sleep(0.025)
    mousePress(b"left")
    # 时间太短了也没法蓄力，可能是和延迟有关系（ps:用的好好的突然就完全用不了了）
    time.sleep(0.7)
    mousePress(b"null")


# 长按启用
def action3():
    try:
        global action3_running
        action3_running = True
        while True:
            keyboardPressAndRelease(b" ", 600)
            keyboardPressAndRelease(b" ", 600)
            mousePress(b"null")
            time.sleep(0.03)
            mouseWheel(-2)
            time.sleep(0.01)
            mousePress(b"left")
            time.sleep(0.3)
            if not action3_running:
                break
    finally:
        keyboardPress(b"null")
        mousePress(b"null")

# 加载DLL
huli_gamepad = ctypes.CDLL("./huli_gamepad.dll")  # 注意路径正确性
# 获取设备句柄，我们的设备输入报告交给这个设备
huli_gamepad.init()

# 配置函数（使其更简洁）
# 键盘按下并释放，参数1字符串，参数2按下时长毫秒ms
keyboardPressAndRelease = huli_gamepad.keyboardPressAndRelease
# 键盘按下，参数1字符串
keyboardPress = huli_gamepad.keyboardPress
# 键盘释放，参数1字符串
keyboardRelease = huli_gamepad.keyboardRelease
# 批量输入字符串，参数1字符串（不包含中文，那是输入法的事）
typewrite = huli_gamepad.typewrite
# 一次按下多个按键，参数n个
hotkey = huli_gamepad.hotkey

# 鼠标相对移动,参数1（x轴正负127），参数2（y轴正负127）
mouseMove = huli_gamepad.mouseMove
# 鼠标绝对移动,参数1（x轴0-65535），参数2（y轴0-65535）
mouseMoveTo = huli_gamepad.mouseMoveTo
# 鼠标点击，参数1字符串
mouseClick = huli_gamepad.mouseClick
# 鼠标按下，参数1字符串
mousePress = huli_gamepad.mousePress
# 鼠标释放，参数1字符串
mouseRelease = huli_gamepad.mouseRelease
# 鼠标滚轮，参数1（x轴正负127）
mouseWheel = huli_gamepad.mouseWheel
# 查看按下状态，键盘按键最多支持6个，键盘修饰符和鼠标按键可全部同时按下。无需参数
checkPress = huli_gamepad.checkPress
# 监听键盘输入
keyboardListenner = huli_gamepad.keyboardListenner

# 终止程序清理
atexit.register(exit_handler)

action1_running = False
action2_running = False
action3_running = False
action1_lock = threading.Lock()
action2_lock = threading.Lock()
action3_lock = threading.Lock()

# 调用测试
if __name__ == "__main__":

    while True:
        # 创建128个结构体的数组
        kb_arr = (NEW_KEYBOARD_INFO * 128)()
        ret = keyboardListenner(kb_arr)
        if ret:
            for count in range(128):
                kb_info = kb_arr[count]
                # 如果有按键内容就输出
                # if kb_info.Button:
                #     print(f"按键：{kb_info.Button}\t状态：{kb_info.IsPress}")

                if kb_info.Button == "Caps Lock" and kb_info.IsPress == "按下" and action3_running == False:
                    action1()

                # if kb_info.Button == "Caps Lock" and kb_info.IsPress == "按下" and action3_running == False:
                #     threading.Thread(target=action3, daemon=True).start()
                # if kb_info.Button == "Caps Lock" and kb_info.IsPress == "抬起" and action3_running == True:
                #     action3_running = False


        else:
            print("函数调用失败")
        time.sleep(0.01)
