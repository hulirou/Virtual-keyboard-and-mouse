import ctypes
from PIL import Image
from PIL import ImageGrab
import imagehash
import time
import atexit
import os
import sys


# 检查图片相似性
def check_image_similarity(img_path1, img_path2):
    # 打开图片
    image1 = Image.open(img_path1)
    image2 = Image.open(img_path2)

    # 计算感知哈希值
    hash1 = imagehash.phash(image1)
    hash2 = imagehash.phash(image2)

    # 计算汉明距离并转换为相似度
    hamming_distance = hash1 - hash2
    similarity = 1 - (hamming_distance / 64)  # 基于64位哈希计算

    # 打印相似度结果
    # print(f"感知哈希相似度: {similarity * 100}%")
    return similarity * 100  # 直接返回百分比


# 两个坐标截图
def capture_rectangle_by_points(x1, y1, x2, y2, save_path):
    # 处理点的顺序问题，获取矩形区域的正确坐标
    left = min(x1, x2)
    top = min(y1, y2)
    right = max(x1, x2)
    bottom = max(y1, y2)

    # 截取矩形区域
    screenshot = ImageGrab.grab(bbox=(left, top, right, bottom))
    screenshot.save(save_path)
    # print(f"截图已保存至：{save_path}")


def moveTo(x, y):
    # mickey_per_pixel = get_mickey_per_pixel()
    # 计算后转换为整数再传递
    huli_gamepad.mouseMoveTo(int(x * 19.53), int(y * 31.25))


def auto_fuben1(huli_gamepad):
    # 开始前清理所有按下键
    huli_gamepad.keyboardPress(b"null")
    huli_gamepad.mousePress(b"null")
    time.sleep(1.2)

    # 判断副本是否正确
    capture_rectangle_by_points(1345, 909, 1504, 930, "图库/临时截图.png")
    similarity = check_image_similarity('./图库/临时截图.png', './图库/雪满弓刀-困难-单人(1345, 909, 1504, 930).png')
    print(f"选择副本图片相似度：{similarity}%")
    if similarity > 92:
        print("副本匹配，准备进入")
        # 点击开始
        moveTo(1487, 976)
        time.sleep(0.1)
        huli_gamepad.mouseClick(b"left")

        time.sleep(20)
        # 选人
        moveTo(173, 437)
        huli_gamepad.mouseClick(b"left")
        time.sleep(1)
        moveTo(1437, 928)
        huli_gamepad.mouseClick(b"left")

        time.sleep(40)
        # 进入副本后前进并传送
        huli_gamepad.keyboardPress(b"w")
        time.sleep(0.1)
        huli_gamepad.keyboardPress(b"shift")
        time.sleep(5)
        huli_gamepad.keyboardRelease(b"w")
        huli_gamepad.keyboardPress(b"shift")

        capture_rectangle_by_points(952, 620, 1011, 642, "./图库/临时截图.png")
        similarity = check_image_similarity('./图库/临时截图.png', './图库/传送.png')
        print(f"判断是否点击传送：{similarity}%")
        if similarity > 92:
            huli_gamepad.keyboardPressAndRelease(b"e", 1000)
            time.sleep(8)
            # 传送后锁定boss
            while True:
                # 判断是否需要跳过剧情
                capture_rectangle_by_points(1559, 1016, 1588, 1030, "./图库/临时截图.png")
                similarity = check_image_similarity('./图库/临时截图.png', './图库/跳过剧情.png')
                if (similarity > 92):
                    huli_gamepad.keyboardPressAndRelease(b"esc", 1000)
                    time.sleep(2)
                    huli_gamepad.keyboardPress(b"w")
                    huli_gamepad.keyboardPressAndRelease(b"`", 500)

                # 主要攻击手段(不知道为什么有时索敌会中断)
                huli_gamepad.keyboardPressAndRelease(b"f", 500)
                huli_gamepad.keyboardPressAndRelease(b"v", 500)
                huli_gamepad.mousePress(b"left")
                time.sleep(1)
                huli_gamepad.mouseRelease(b"left")

                # 判断副本如果成功打完
                capture_rectangle_by_points(67, 119, 172, 170, "./图库/临时截图.png")
                similarity = check_image_similarity('./图库/临时截图.png', './图库/胜利.png')
                if similarity > 95:
                    print(f"副本胜利！")
                    global count
                    count += 1
                    print(f"已完成副本{count}次")
                    huli_gamepad.keyboardPress(b"null")
                    huli_gamepad.mousePress(b"null")
                    time.sleep(1)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    break

                # 判断副本如果失败了
                capture_rectangle_by_points(69, 117, 171, 171, "./图库/临时截图.png")
                similarity = check_image_similarity('./图库/临时截图.png', './图库/失败.png')
                if similarity > 95:
                    print(f"副本胜利！")
                    print("完成")
                    huli_gamepad.keyboardPress(b"null")
                    huli_gamepad.mousePress(b"null")
                    time.sleep(1)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    break


        else:
            print("未能找到传送")
            huli_gamepad.keyboardPress(b"w")
            time.sleep(7)
            huli_gamepad.keyboardPressAndRelease(b"e", 1000)


    else:
        print("副本不匹配,重新尝试！")


def auto_fuben2(huli_gamepad):
    # 开始前清理所有按下键
    huli_gamepad.keyboardPress(b"null")
    huli_gamepad.mousePress(b"null")
    time.sleep(1.2)

    # 判断副本是否正确
    capture_rectangle_by_points(1346, 908, 1502, 931, "图库/临时截图.png")
    similarity = check_image_similarity('./图库/临时截图.png', './图库/狮影霆威-困难-单人(1346, 908, 1502, 931).png')
    print(f"选择副本图片相似度：{similarity}%")
    if similarity > 92:
        print("副本匹配，准备进入")
        # 点击开始
        moveTo(1487, 976)
        time.sleep(0.1)
        huli_gamepad.mouseClick(b"left")

        time.sleep(20)
        # 选人
        moveTo(173, 437)
        huli_gamepad.mouseClick(b"left")
        time.sleep(1)
        moveTo(1437, 928)
        huli_gamepad.mouseClick(b"left")

        time.sleep(40)
        # 进入副本后前进并传送
        huli_gamepad.keyboardPress(b"w")
        time.sleep(0.1)
        huli_gamepad.keyboardPress(b"shift")
        time.sleep(5)
        huli_gamepad.keyboardRelease(b"w")
        huli_gamepad.keyboardPress(b"shift")

        capture_rectangle_by_points(952, 620, 1011, 642, "./图库/临时截图.png")
        similarity = check_image_similarity('./图库/临时截图.png', './图库/传送.png')
        print(f"判断是否点击传送：{similarity}%")
        if similarity > 92:
            huli_gamepad.keyboardPressAndRelease(b"e", 1000)
            time.sleep(8)
            # 传送后锁定boss
            while True:
                # 判断是否需要跳过剧情
                capture_rectangle_by_points(1559, 1016, 1588, 1030, "./图库/临时截图.png")
                similarity = check_image_similarity('./图库/临时截图.png', './图库/跳过剧情.png')
                if (similarity > 92):
                    huli_gamepad.keyboardPressAndRelease(b"esc", 1000)
                    time.sleep(2)
                    huli_gamepad.keyboardPress(b"w")
                    huli_gamepad.keyboardPressAndRelease(b"`", 500)

                # 主要攻击手段(不知道为什么有时索敌会中断)
                huli_gamepad.keyboardPressAndRelease(b"f", 500)
                huli_gamepad.keyboardPressAndRelease(b"v", 500)
                huli_gamepad.mousePress(b"left")
                time.sleep(1)
                huli_gamepad.mouseRelease(b"left")

                # 判断副本如果成功打完
                capture_rectangle_by_points(67, 119, 172, 170, "./图库/临时截图.png")
                similarity = check_image_similarity('./图库/临时截图.png', './图库/胜利.png')
                if similarity > 95:
                    print(f"副本胜利！")
                    global count
                    count += 1
                    print(f"已完成副本{count}次")

                    huli_gamepad.keyboardPress(b"null")
                    huli_gamepad.mousePress(b"null")
                    time.sleep(1)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    break

                # 判断副本如果失败了
                capture_rectangle_by_points(69, 117, 171, 171, "./图库/临时截图.png")
                similarity = check_image_similarity('./图库/临时截图.png', './图库/失败.png')
                if similarity > 95:
                    print(f"副本胜利！")
                    print("完成")
                    huli_gamepad.keyboardPress(b"null")
                    huli_gamepad.mousePress(b"null")
                    time.sleep(1)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    huli_gamepad.keyboardPressAndRelease(b" ", 1000)
                    break
        else:
            print("未能找到传送")
            huli_gamepad.keyboardPress(b"w")
            time.sleep(7)
            huli_gamepad.keyboardPressAndRelease(b"e", 1000)


    else:
        print("副本不匹配,重新尝试！")


# 取消自动关机
def cancel_shutdown():
    if sys.platform.startswith('win'):
        # Windows系统取消关机命令
        os.system('shutdown /a')
    elif sys.platform.startswith('linux') or sys.platform.startswith('darwin'):
        # Linux/macOS系统取消关机命令
        os.system('shutdown -c')
    else:
        print("不支持的操作系统")


# 注册退出处理函数否者按退出键可能有错
def exit_handler():
    print("程序即将退出，执行清理操作...")
    huli_gamepad.keyboardPress(b"null")
    huli_gamepad.mousePress(b"null")
    # 取消自动关机
    cancel_shutdown()
    print("已取消自动关机")

    # 自动关机


def shutdown_after_sometime(hours):
    seconds = hours * 3600
    os.system(f'shutdown /s /t {seconds}')


if __name__ == '__main__':
    time.sleep(1)
    huli_gamepad = ctypes.CDLL("./huli_gamepad.dll")  # 注意路径正确性
    huli_gamepad.init()

    # 注册退出处理函数否者按退出键可能有错
    atexit.register(exit_handler)
    # 自动关机
    shutdown_after_sometime(7)

    count = 0
    while True:
        auto_fuben2(huli_gamepad)
        time.sleep(5)
