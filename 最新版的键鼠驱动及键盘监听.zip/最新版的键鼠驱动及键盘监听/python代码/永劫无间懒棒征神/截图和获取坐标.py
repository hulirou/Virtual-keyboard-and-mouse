import tkinter as tk
from tkinter import messagebox
from PIL import ImageGrab
import time


class ScreenshotSelector:
    def __init__(self, root):
        self.root = root
        self.root.attributes("-fullscreen", True)  # 全屏显示
        self.root.attributes("-alpha", 0.3)  # 半透明
        self.root.attributes("-topmost", True)  # 窗口置顶

        # 创建画布用于绘制选择框
        self.canvas = tk.Canvas(root, cursor="cross")
        self.canvas.pack(fill=tk.BOTH, expand=True)

        # 初始化变量
        self.start_x = None
        self.start_y = None
        self.rect = None
        self.point1 = None
        self.point2 = None

        # 绑定鼠标事件
        self.canvas.bind("<ButtonPress-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)

        # 显示提示信息
        self.show_instructions()

    def show_instructions(self):
        """显示操作提示"""
        msg = "按住鼠标左键拖拽选择区域，松开后完成选择"
        self.canvas.create_text(
            self.root.winfo_screenwidth() // 2,
            self.root.winfo_screenheight() // 2,
            text=msg,
            font=("Arial", 16),
            fill="red"
        )

    def on_press(self, event):
        """记录鼠标按下时的坐标"""
        self.start_x = event.x
        self.start_y = event.y
        # 清除之前的矩形
        if self.rect:
            self.canvas.delete(self.rect)
            self.rect = None

    def on_drag(self, event):
        """拖拽时绘制矩形"""
        if self.rect:
            self.canvas.delete(self.rect)
        # 绘制临时矩形
        self.rect = self.canvas.create_rectangle(
            self.start_x, self.start_y,
            event.x, event.y,
            outline="red", width=2
        )

    def on_release(self, event):
        """释放鼠标时计算坐标并关闭窗口"""
        # 记录两个对角点坐标
        self.point1 = (self.start_x, self.start_y)
        self.point2 = (event.x, event.y)

        # 确保坐标顺序正确（左上到右下）
        self.left = min(self.point1[0], self.point2[0])
        self.top = min(self.point1[1], self.point2[1])
        self.right = max(self.point1[0], self.point2[0])
        self.bottom = max(self.point1[1], self.point2[1])

        # 关闭选择窗口
        self.root.destroy()


def get_selected_area_coordinates():
    """获取用户选择区域的坐标"""
    root = tk.Tk()
    root.title("选择截图区域")
    selector = ScreenshotSelector(root)
    root.mainloop()

    # 返回两个对角点坐标和规范化的区域坐标
    return {
        "point1": selector.point1,
        "point2": selector.point2,
        "area": (selector.left, selector.top, selector.right, selector.bottom)
    }


if __name__ == "__main__":
    print("2秒后将显示选择界面，请用鼠标框选需要截取的区域...")
    time.sleep(2)  # 延迟2秒，方便切换到目标窗口

    # 获取选择的区域坐标
    selected = get_selected_area_coordinates()

    # 显示坐标信息
    print(f"\n选择的两个对角点坐标：")
    print(f"点1: {selected['point1']}")
    print(f"点2: {selected['point2']}")
    print(f"区域坐标（左, 上, 右, 下）: {selected['area']}")

    # 截取并保存选择的区域
    screenshot = ImageGrab.grab(bbox=selected['area'])
    save_path = "图库/临时截图.png"
    screenshot.save(save_path)
    print(f"\n截图已保存至：{save_path}")

    # 弹窗提示完成
    root = tk.Tk()
    root.withdraw()  # 隐藏主窗口
    messagebox.showinfo("完成", f"已获取坐标并保存截图\n点1: {selected['point1']}\n点2: {selected['point2']}")
    root.destroy()
