#include "mydll.h"
#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <initguid.h>
#include <SetupAPI.h>
#include <iostream>
#include <limits>
#pragma comment(lib, "setupapi.lib")

//��������루�����޷���
#define IOCTL_TEST CTL_CODE(FILE_DEVICE_UNKNOWN, 0X800, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_Keyboard CTL_CODE(FILE_DEVICE_UNKNOWN, 0X801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_Mouse CTL_CODE(FILE_DEVICE_UNKNOWN, 0X802, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_TouchScreen CTL_CODE(FILE_DEVICE_UNKNOWN, 0X803, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_KeyboardListener CTL_CODE(FILE_DEVICE_UNKNOWN, 0x804, METHOD_BUFFERED, FILE_ANY_ACCESS)

// {685186F1-995E-40E4-BDD4-184723D15E94}
DEFINE_GUID(DEVICEINTERFACE,
    0x685186f1, 0x995e, 0x40e4, 0xbd, 0xd4, 0x18, 0x47, 0x23, 0xd1, 0x5e, 0x94);








//ȫ�ֱ�����¼�����Ƿ���
KeyInfo keyboardPressInfo[6] = { NULL };
uint8_t modifiersPressInfo = 0x00;
uint8_t mousePressInfo = 0x00;
// ȫ�ֱ�������������������ʹ���豸���
HANDLE g_hDevice = INVALID_HANDLE_VALUE;








//���̵ļ�ֵת��
KeyInfo keyboardToKeyCode(const char* keyStr) {
    // ��ʼ������ֵ������isShiftĬ��ֵ"null"
    KeyInfo result = { keyStr, "null", 0x00, false,false };

    // �������ַ���������ĸ�����֡����ţ�
    if (strlen(keyStr) == 1) {
        char c = keyStr[0];
        switch (c) {
        case 'A':
            result.keyCode = 4;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'a':
            result.keyCode = 4;
            result.isBig = false;
            return result;
        case 'B':
            result.keyCode = 5;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'b':
            result.keyCode = 5;
            result.isBig = false;
            return result;
        case 'C':
            result.keyCode = 6;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'c':
            result.keyCode = 6;
            result.isBig = false;
            return result;
        case 'D':
            result.keyCode = 7;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'd':
            result.keyCode = 7;
            result.isBig = false;
            return result;
        case 'E':
            result.keyCode = 8;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'e':
            result.keyCode = 8;
            result.isBig = false;
            return result;
        case 'F':
            result.keyCode = 9;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'f':
            result.keyCode = 9;
            result.isBig = false;
            return result;
        case 'G':
            result.keyCode = 10;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'g':
            result.keyCode = 10;
            result.isBig = false;
            return result;
        case 'H':
            result.keyCode = 11;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'h':
            result.keyCode = 11;
            result.isBig = false;
            return result;
        case 'I':
            result.keyCode = 12;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'i':
            result.keyCode = 12;
            result.isBig = false;
            return result;
        case 'J':
            result.keyCode = 13;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'j':
            result.keyCode = 13;
            result.isBig = false;
            return result;
        case 'K':
            result.keyCode = 14;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'k':
            result.keyCode = 14;
            result.isBig = false;
            return result;
        case 'L':
            result.keyCode = 15;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'l':
            result.keyCode = 15;
            result.isBig = false;
            return result;
        case 'M':
            result.keyCode = 16;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'm':
            result.keyCode = 16;
            result.isBig = false;
            return result;
        case 'N':
            result.keyCode = 17;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'n':
            result.keyCode = 17;
            result.isBig = false;
            return result;
        case 'O':
            result.keyCode = 18;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'o':
            result.keyCode = 18;
            result.isBig = false;
            return result;
        case 'P':
            result.keyCode = 19;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'p':
            result.keyCode = 19;
            result.isBig = false;
            return result;
        case 'Q':
            result.keyCode = 20;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'q':
            result.keyCode = 20;
            result.isBig = false;
            return result;
        case 'R':
            result.keyCode = 21;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'r':
            result.keyCode = 21;
            result.isBig = false;
            return result;
        case 'S':
            result.keyCode = 22;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 's':
            result.keyCode = 22;
            result.isBig = false;
            return result;
        case 'T':
            result.keyCode = 23;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 't':
            result.keyCode = 23;
            result.isBig = false;
            return result;
        case 'U':
            result.keyCode = 24;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'u':
            result.keyCode = 24;
            result.isBig = false;
            return result;
        case 'V':
            result.keyCode = 25;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'v':
            result.keyCode = 25;
            result.isBig = false;
            return result;
        case 'W':
            result.keyCode = 26;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'w':
            result.keyCode = 26;
            result.isBig = false;
            return result;
        case 'X':
            result.keyCode = 27;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'x':
            result.keyCode = 27;
            result.isBig = false;
            return result;
        case 'Y':
            result.keyCode = 28;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'y':
            result.keyCode = 28;
            result.isBig = false;
            return result;
        case 'Z':
            result.keyCode = 29;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case 'z':
            result.keyCode = 29;
            result.isBig = false;
            return result;

        case '1':
            result.keyCode = 30;
            return result;
        case '!':
            result.keyCode = 30;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '2':
            result.keyCode = 31;
            return result;
        case '@':
            result.keyCode = 31;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '3':
            result.keyCode = 32;
            return result;
        case '#':
            result.keyCode = 32;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '4':
            result.keyCode = 33;
            return result;
        case '$':
            result.keyCode = 33;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '5':
            result.keyCode = 34;
            return result;
        case '%':
            result.keyCode = 34;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '6':
            result.keyCode = 35;
            return result;
        case '^':
            result.keyCode = 35;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '7':
            result.keyCode = 36;
            return result;
        case '&':
            result.keyCode = 36;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '8':
            result.keyCode = 37;
            return result;
        case '*':
            result.keyCode = 37;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '9':
            result.keyCode = 38;
            return result;
        case '(':
            result.keyCode = 38;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '0':
            result.keyCode = 39;
            return result;
        case ')':
            result.keyCode = 39;
            result.isBig = true;
            result.isShift = "shift";
            return result;


        case '-':
            result.keyCode = 45;
            return result;
        case '_':
            result.keyCode = 45;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '=':
            result.keyCode = 46;
            return result;
        case '+':
            result.keyCode = 46;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '[':
            result.keyCode = 47;
            return result;
        case '{':
            result.keyCode = 47;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case ']':
            result.keyCode = 48;
            return result;
        case '}':
            result.keyCode = 48;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '\\':
            result.keyCode = 50;
            return result;
        case '|':
            result.keyCode = 50;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case ';':
            result.keyCode = 51;
            return result;
        case ':':
            result.keyCode = 51;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '\'':
            result.keyCode = 52;
            return result;
        case '"':
            result.keyCode = 52;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '`':
            result.keyCode = 53;
            return result;
        case '~':
            result.keyCode = 53;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case ',':
            result.keyCode = 54;
            return result;
        case '<':
            result.keyCode = 54;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '.':
            result.keyCode = 55;
            return result;
        case '>':
            result.keyCode = 55;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case '/':
            result.keyCode = 56;
            return result;
        case '?':
            result.keyCode = 56;
            result.isBig = true;
            result.isShift = "shift";
            return result;
        case ' ':
            result.keyCode = 44;
            return result;
        default:
            return result;  // δ֪���ַ�������Ĭ��ֵ
        }
    }
    // �������ַ������,��Shift״̬
    else {
        if (_stricmp(keyStr, "Ctrl") == 0) {
            result.keyCode = 1;
            result.isModifier = true;
        }
        else if (_stricmp(keyStr, "��Ctrl") == 0) {
            result.keyCode = 16;
            result.isModifier = true;
        }
        else if (_stricmp(keyStr, "Shift") == 0) {
            result.keyCode = 2;
            result.isModifier = true;
        }
        else if (_stricmp(keyStr, "��Shift") == 0) {
            result.keyCode = 32;
            result.isModifier = true;
        }
        else if (_stricmp(keyStr, "Alt") == 0) {
            result.keyCode = 4;
            result.isModifier = true;
        }
        else if (_stricmp(keyStr, "��Alt") == 0) {
            result.keyCode = 64;
            result.isModifier = true;
        }
        else if (_stricmp(keyStr, "GUI") == 0) {
            result.keyCode = 8;
            result.isModifier = true;
        }
        else if (_stricmp(keyStr, "��GUI") == 0) {
            result.keyCode = 128;
            result.isModifier = true;
        }
        else if (_stricmp(keyStr, "win") == 0) {
            result.keyCode = 8;
            result.isModifier = true;
        }
        else if (_stricmp(keyStr, "��win") == 0) {
            result.keyCode = 128;
            result.isModifier = true;
        }



        if (_stricmp(keyStr, "Tab") == 0)
            result.keyCode = 43;
        else if (_stricmp(keyStr, "Enter") == 0)
            result.keyCode = 40;
        else if (_stricmp(keyStr, "Escape") == 0)
            result.keyCode = 41;
        else if (_stricmp(keyStr, "Esc") == 0)
            result.keyCode = 41;
        else if (_stricmp(keyStr, "Backspace") == 0)
            result.keyCode = 42;
        else if (_stricmp(keyStr, "Caps Lock") == 0)
            result.keyCode = 57;
        else if (_stricmp(keyStr, "Space") == 0)
            result.keyCode = 44;
        else if (_stricmp(keyStr, "F1") == 0)
            result.keyCode = 58;
        else if (_stricmp(keyStr, "F2") == 0)
            result.keyCode = 59;
        else if (_stricmp(keyStr, "F3") == 0)
            result.keyCode = 60;
        else if (_stricmp(keyStr, "F4") == 0)
            result.keyCode = 61;
        else if (_stricmp(keyStr, "F5") == 0)
            result.keyCode = 62;
        else if (_stricmp(keyStr, "F6") == 0)
            result.keyCode = 63;
        else if (_stricmp(keyStr, "F7") == 0)
            result.keyCode = 64;
        else if (_stricmp(keyStr, "F8") == 0)
            result.keyCode = 65;
        else if (_stricmp(keyStr, "F9") == 0)
            result.keyCode = 66;
        else if (_stricmp(keyStr, "F10") == 0)
            result.keyCode = 67;
        else if (_stricmp(keyStr, "F11") == 0)
            result.keyCode = 68;
        else if (_stricmp(keyStr, "F12") == 0)
            result.keyCode = 69;
        else if (_stricmp(keyStr, "PrintScreen") == 0)
            result.keyCode = 70;
        else if (_stricmp(keyStr, "ScrollLock") == 0)
            result.keyCode = 71;
        else if (_stricmp(keyStr, "Pause") == 0)
            result.keyCode = 72;
        else if (_stricmp(keyStr, "Insert") == 0)
            result.keyCode = 73;
        else if (_stricmp(keyStr, "Home") == 0)
            result.keyCode = 74;
        else if (_stricmp(keyStr, "PageUp") == 0)
            result.keyCode = 75;
        else if (_stricmp(keyStr, "Delete") == 0)
            result.keyCode = 76;
        else if (_stricmp(keyStr, "End") == 0)
            result.keyCode = 77;
        else if (_stricmp(keyStr, "PageDown") == 0)
            result.keyCode = 78;
        else if (_stricmp(keyStr, "Left") == 0)
            result.keyCode = 80;
        else if (_stricmp(keyStr, "Down") == 0)
            result.keyCode = 81;
        else if (_stricmp(keyStr, "Up") == 0)
            result.keyCode = 82;
        else if (_stricmp(keyStr, "Right") == 0)
            result.keyCode = 79;
        else if (_stricmp(keyStr, "Null") == 0)
            result.keyCode = 0;


        return result;
    }
}

//���ļ�ֵת��
uint8_t mousueToKeyCode(const char* keyStr) {
    uint8_t mouseInfo = 0;
    if (_stricmp(keyStr, "left") == 0) {
        mouseInfo = 1;
    }
    else if (_stricmp(keyStr, "right") == 0) {
        mouseInfo = 2;
    }
    else if (_stricmp(keyStr, "mid") == 0) {
        mouseInfo = 4;
    }
    else if (_stricmp(keyStr, "x1") == 0) {
        mouseInfo = 8;
    }
    else if (_stricmp(keyStr, "x2") == 0) {
        mouseInfo = 16;
    }
    else {
        mouseInfo = 0;
    }
    return mouseInfo;

}

//�����ļ��̼�ֵת��
const wchar_t* ScancodeToButton(uint8_t scancode) {
    switch (scancode) {
    case 1:  return L"ESC";
    case 2:  return L"1";
    case 3:  return L"2";
    case 4:  return L"3";
    case 5:  return L"4";
    case 6:  return L"5";
    case 7:  return L"6";
    case 8:  return L"7";
    case 9:  return L"8";
    case 10: return L"9";
    case 11: return L"0";
    case 12: return L"-";
    case 13: return L"=";
    case 14: return L"Backspace";
    case 15: return L"Tab";
    case 16: return L"Q";
    case 17: return L"W";
    case 18: return L"E";
    case 19: return L"R";
    case 20: return L"T";
    case 21: return L"Y";
    case 22: return L"U";
    case 23: return L"I";
    case 24: return L"O";
    case 25: return L"P";
    case 26: return L"[";
    case 27: return L"]";
    case 28: return L"Enter";
    case 29: return L"Ctrl";
    case 30: return L"A";
    case 31: return L"S";
    case 32: return L"D";
    case 33: return L"F";
    case 34: return L"G";
    case 35: return L"H";
    case 36: return L"J";
    case 37: return L"K";
    case 38: return L"L";
    case 39: return L";";
    case 40: return L"'";
    case 41: return L"`";
    case 42: return L"Shift";
    case 43: return L"\\";
    case 44: return L"Z";
    case 45: return L"X";
    case 46: return L"C";
    case 47: return L"V";
    case 48: return L"B";
    case 49: return L"N";
    case 50: return L"M";
    case 51: return L",";
    case 52: return L".";
    case 53: return L"/";
    case 54: return L"Right Shift";
    case 55: return L"* (Numpad)";
    case 56: return L"Alt";//���Ҷ���
    case 57: return L"Space";
    case 58: return L"Caps Lock";
    case 59: return L"F1";
    case 60: return L"F2";
    case 61: return L"F3";
    case 62: return L"F4";
    case 63: return L"F5";
    case 64: return L"F6";
    case 65: return L"F7";
    case 66: return L"F8";
    case 67: return L"F9";
    case 68: return L"F10";
    case 87: return L"F11";
    case 88: return L"F12";
    case 69: return L"Num Lock";

        // ����ȱʧ��ɨ���루�ص��ע�ظ�ɨ�����Ӧ�İ�����
    case 71: return L"7(Numpad)";      // С����7
    case 72: return L"8(Numpad)";      // С����8
    case 73: return L"9(Numpad)";      // С����9
    case 74: return L"-(Numpad)";      // С���̼���
    case 75: return L"4(Numpad)";      // С����4
    case 76: return L"5(Numpad)";      // С����5
    case 77: return L"6(Numpad)";      // С����6
    case 78: return L"+(Numpad)";      // С���̼Ӻ�
    case 79: return L"1(Numpad)";      // С����1
    case 80: return L"2(Numpad)";       // С����2
    case 81: return L"3(Numpad)";      // С����3
    case 82: return L"0(Numpad)";      // С����0
    case 83: return L".(Numpad)";      // С����С����

    case 91: return L"Win";            // win��
    default: return L"UNKNOWN";
    }
}


//�����Ӧ��λ�Ƿ񱻰���
void addModifierPress(uint8_t modifierKey) {
    modifiersPressInfo = modifiersPressInfo | modifierKey;
}

void removeModifierPress(uint8_t modifierKey) {
    modifiersPressInfo = modifiersPressInfo & ~modifierKey;
}

void addMousePress(uint8_t mouseKey) {
    mousePressInfo = mousePressInfo | mouseKey;
}

void removeMousePress(uint8_t mouseKey) {
    mousePressInfo = mousePressInfo & ~mouseKey;
}




// д����̰���״̬(���η�ֱ��ִ�м��㺯������ťִ������������)
bool addKeyboardPress(const char* str) {



    if (keyboardToKeyCode(str).keyCode == 0x00) {
        for (int i = 0; i < 6; i++) {
            keyboardPressInfo[6] = { NULL };
        }
        modifiersPressInfo = 0x00;
        return true;
    }



    if (keyboardToKeyCode(str).isModifier == true) {
        addModifierPress(keyboardToKeyCode(str).keyCode);
        return true;
    }
    else {
        // 1. ����Ƿ��Ѵ�����ͬ�������Ƚ�str��ṹ���button��
        for (int i = 0; i < 6; i++) {
            // ���ж�button�Ƿ�ΪNULL�������ָ�����
            if (keyboardPressInfo[i].button != NULL && _stricmp(keyboardPressInfo[i].button, str) == 0) {
                //wprintf(L"�ð����Ѱ���: %s\n", str);
                return false;
            }
        }

        // 2. Ѱ�ҿ�λ������ת�����KeyInfo
        for (int i = 0; i < 6; i++) {
            if (keyboardPressInfo[i].button == NULL) {  // ��λ�ж�
                keyboardPressInfo[i] = keyboardToKeyCode(str);
                //wprintf(L"��������״̬�Ѽ�¼: %s\n", str);
                return true;
            }
        }

        wprintf(L"���µİ����Ѵ�����\n");
        return false;
    }
}


// �Ƴ����̰���״̬(�����Ƿ������η�)
bool removeKeyboardPress(const char* str) {

    if (keyboardToKeyCode(str).keyCode == 0x00) {
        for (int i = 0; i < 6; i++) {
            keyboardPressInfo[6] = { NULL };
        }
        modifiersPressInfo = 0x00;
        return true;
    }

    if (keyboardToKeyCode(str).isModifier == true) {
        removeModifierPress(keyboardToKeyCode(str).keyCode);
        return true;
    }
    else {
        for (int i = 0; i < 6; i++) {
            // ���ж�button�Ƿ�ΪNULL�������ָ�����
            if (keyboardPressInfo[i].button != NULL &&
                _stricmp(keyboardPressInfo[i].button, str) == 0) {  // ���ıȽ��߼�
                // ��ո�λ�õĽṹ�壨�ָ���ʼ״̬��
                keyboardPressInfo[i].button = NULL;
                keyboardPressInfo[i].keyCode = 0x00;
                keyboardPressInfo[i].isBig = false;
                //wprintf(L"ɾ�������ɹ�: %s\n", str);
                return true;
            }
        }

        wprintf(L"�ð���δ���£��޷�ɾ��: %s\n", str);
        return false;
    }
}




















//��ȡ�豸����Ͷ������utf-8
void init() {

    //���utf-8�ÿ��ַ������pythonҲ���������
    setlocale(LC_ALL, "en_US.UTF-8"); // �ؼ���ָ���ն˱���Ϊ UTF-8



    //������������Ҫ֪����ʹ��GUID�������з����豸ȡ����һ�����豸·��
    LPTSTR DevicePath = NULL;
    HDEVINFO hInfo = SetupDiGetClassDevs(&DEVICEINTERFACE, NULL, NULL, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);

    if (hInfo == NULL) {
        wprintf(L"��ȡ�豸��Ϣ�б�ʧ��: %d\n", GetLastError());
        return;
    }


    SP_DEVICE_INTERFACE_DATA ifdata = { 0 };
    ifdata.cbSize = sizeof(ifdata);
    if (!SetupDiEnumDeviceInterfaces(hInfo, NULL, &DEVICEINTERFACE, 0, &ifdata)) {
        wprintf(L"ö�ٽӿ�ʧ��%d\n", GetLastError());
        SetupDiDestroyDeviceInfoList(hInfo);  // <-- �޸ģ�������Դ�ͷ�
        return;
    }

    PSP_DEVICE_INTERFACE_DETAIL_DATA pdetailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(1024);
    DWORD dwSize = 0;
    RtlZeroMemory(pdetailData, 1024);
    pdetailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
    if (!SetupDiGetDeviceInterfaceDetail(hInfo, &ifdata, pdetailData, 1024, &dwSize, NULL)) {
        free(pdetailData);  // <-- �޸ģ�������Դ�ͷ�
        SetupDiDestroyDeviceInfoList(hInfo);  // <-- �޸ģ�������Դ�ͷ�
        wprintf(L"��ȡ�豸�ӿ�����ʧ��: %d\n", GetLastError());
        return;
    }

    // �����豸·����������ָ��
    DevicePath = (LPTSTR)LocalAlloc(LPTR, (lstrlen(pdetailData->DevicePath) + 1) * sizeof(TCHAR));  // <-- �޸ģ�����·��
    lstrcpy(DevicePath, pdetailData->DevicePath);
    free(pdetailData);
    SetupDiDestroyDeviceInfoList(hInfo);  // <-- �޸ģ��ͷ��豸��Ϣ�б�


    // �ٸ����豸·����ȡ�豸�������ֵ��ȫ�ֱ���
    if (DevicePath != NULL) {
        wprintf(L"�豸·��%ls\n", DevicePath);
        g_hDevice = CreateFile(DevicePath, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);  // <-- �޸ģ���ȡ�������ֵȫ�ֱ���
        LocalFree(DevicePath);  // <-- �޸ģ��ͷ�·���ڴ�

        if (g_hDevice == INVALID_HANDLE_VALUE) {  // <-- �޸ģ��������Ч��
            wprintf(L"��ȡ�豸���ʧ��: %d\n", GetLastError());
        }
    }
    else {
        wprintf(L"�豸�ӿڻ�ȡʧ��: %d\n", GetLastError());
    }

}


//���ͼ��̱��浽��������
bool sendKeyboardReportToDriver(KEYBOARD_INPUT_REPORT sendData) {
    DWORD dwret;
    char outBuffer[1024] = { 0 };

    // �������ݵ��豸
    BOOL success = DeviceIoControl(
        g_hDevice,
        IOCTL_Keyboard,
        &sendData,
        sizeof(sendData),
        outBuffer,
        sizeof(outBuffer),
        &dwret,
        NULL
    );
    if (!success) {
        return false;
    }
    else {
        return true;
    }
}
//������걨�浽��������
bool sendMouseReportToDriver(MOUSE_INPUT_REPORT sendData) {
    DWORD dwret;
    char outBuffer[1024] = { 0 };

    // �������ݵ��豸
    BOOL success = DeviceIoControl(
        g_hDevice,
        IOCTL_Mouse,
        &sendData,
        sizeof(sendData),
        outBuffer,
        sizeof(outBuffer),
        &dwret,
        NULL
    );
    if (!success) {
        wprintf(L"�������ݵ�����ʧ��: %d\n", GetLastError());
        return false;
    }
    else {
        return true;
    }
}
//���ʹ��������浽��������
bool sendTouchScreenReportToDriver(TOUCHSCREEN_INPUT_REPORT sendData) {
    DWORD dwret;
    char outBuffer[1024] = { 0 };

    // �������ݵ��豸
    BOOL success = DeviceIoControl(
        g_hDevice,
        IOCTL_TouchScreen,
        &sendData,
        sizeof(sendData),
        outBuffer,
        sizeof(outBuffer),
        &dwret,
        NULL
    );
    if (!success) {
        wprintf(L"�������ݵ�����ʧ��: %d\n", GetLastError());
        return false;
    }
    else {
        return true;
    }
}





//��Ҫ������
//���̰���
bool keyboardPress(const char* KeyCodes) {
    KEYBOARD_INPUT_REPORT keyboardData = { 0 };
    KeyInfo keyInfo = keyboardToKeyCode(KeyCodes);
    keyboardData.ReportId = 1;


    //�����0x00�ͻ�ԭȫ�֣��������ɾ������״̬�������ֵ�����ֵ��������
    if (keyInfo.keyCode == 0x00) {
        memset(keyboardPressInfo, 0, sizeof(keyboardPressInfo));
        modifiersPressInfo = 0x00;
    }
    else {
        addKeyboardPress(KeyCodes);
    }


    //���������а��µİ��������η����������з��͵�����
    for (int i = 0; i <= 5; i++) {
        keyboardData.ScanCodes[i] = keyboardPressInfo[i].keyCode;
    }
    keyboardData.Modifiers = modifiersPressInfo;
    if (!sendKeyboardReportToDriver(keyboardData)) {
        return false;
    }
    return true;
}

//�����ͷ�
bool keyboardRelease(const char* KeyCodes) {
    KEYBOARD_INPUT_REPORT keyboardData = { 0 };
    KeyInfo keyInfo = keyboardToKeyCode(KeyCodes);
    keyboardData.ReportId = 1;

    //�����0x00�ͻ�ԭȫ�֣��������ɾ������״̬�������ֵ�����ֵ��������
    if (keyInfo.keyCode == 0x00) {
        memset(keyboardPressInfo, 0, sizeof(keyboardPressInfo));
        modifiersPressInfo = 0x00;
    }
    else {
        removeKeyboardPress(KeyCodes);
    }

    //���������а��µİ��������η����������з��͵�����
    for (int i = 0; i <= 5; i++) {
        keyboardData.ScanCodes[i] = keyboardPressInfo[i].keyCode;
    }
    keyboardData.Modifiers = modifiersPressInfo;
    if (!sendKeyboardReportToDriver(keyboardData)) {
        return false;
    }

}

//���¼��̺��ͷź���
bool keyboardPressAndRelease(const char* KeyCodes, int time_ms) {
    bool success = keyboardPress(KeyCodes);
    if (!success) {
        wprintf(L"���Ͱ��¼������뱨��ʧ��\n");
        return false;
    }
    Sleep(time_ms);


    success = keyboardRelease(KeyCodes);
    if (!success) {
        wprintf(L"�����ͷż������뱨��ʧ��\n");
        return false;
    }

    return true;
}

//�����ı�
bool typewrite(const char* keyStr, int time_ms) {


    int strLen = strlen(keyStr);
    if (strLen == 0 || keyStr == NULL) {
        wprintf(L"�����ַ���Ϊ��\n");
        return false;
    }

    for (int i = 0; i < strLen; i++) {
        char currentChar = keyStr[i];
        char singleChar[2] = { currentChar, '\0' };
        KeyInfo keyInfo = keyboardToKeyCode(singleChar);

        if (keyInfo.keyCode == 0x00) {
            wprintf(L"����δ֪�ַ� '%c'���������ַ�\n", currentChar);
            continue;
        }
        else {
            wprintf(L"����: '%c'����ֵ��: 0x%02X\n", currentChar, keyInfo.keyCode);
            if (keyInfo.isBig) {
                keyboardPress("shift");
            }
            keyboardPressAndRelease(keyInfo.button, time_ms);
            if (keyInfo.isBig) {
                keyboardRelease("shift");
            }
        }
    }
    return true;
}

// ��ϰ���
bool hotkey(const char* args[]) {
    // ��������е����ݣ����6��������nullptr��ֹͣ
    for (int i = 0; i < 6; i++) {
        // ���������ָ�룬˵�����ݽ���
        if (args[i] == nullptr) {
            break;
        }
        keyboardPress(args[i]);
    }
    Sleep(50);
    for (int i = 0; i < 6; i++) {
        // ���������ָ�룬˵�����ݽ���
        if (args[i] == nullptr) {
            break;
        }
        keyboardRelease(args[i]);
    }
    return true;
}

//����ƶ����
bool mouseMove(int8_t deltaX, int8_t deltaY) {

    MOUSE_INPUT_REPORT mouseData = { 0 };
    mouseData.ReportId = 2;
    mouseData.Buttons = 0x80;
    mouseData.DeltaX = deltaX;
    mouseData.DeltaY = deltaY;
    mouseData.WheelDelta = 0;

    if (!sendMouseReportToDriver(mouseData)) {
        return false;
    }
    return true;
}

//�����ƶ����
bool mouseMoveTo(uint16_t deltaX, uint16_t deltaY) {

    TOUCHSCREEN_INPUT_REPORT touchScreenData = { 0 };
    touchScreenData.ReportId = 3;
    touchScreenData.Buttons = 0x00;
    touchScreenData.DeltaX = deltaX;
    touchScreenData.DeltaY = deltaY;

    if (!sendTouchScreenReportToDriver(touchScreenData)) {
        return false;
    }
    return true;
}

//�����
bool mouseClick(const char* buttons) {
    uint8_t keyCode = mousueToKeyCode(buttons);
    addMousePress(keyCode);
    wprintf(L"keyCode: 0x%02X\n", keyCode);


    MOUSE_INPUT_REPORT mouseData = { 0 };
    mouseData.ReportId = 2;
    mouseData.Buttons = mousePressInfo;
    mouseData.DeltaX = 0;
    mouseData.DeltaY = 0;
    mouseData.WheelDelta = 0;

    if (!sendMouseReportToDriver(mouseData)) {
        return false;
    }



    //ֻ�ͷŰ��µİ�ť
    removeMousePress(keyCode);
    mouseData.Buttons = mousePressInfo;
    if (!sendMouseReportToDriver(mouseData)) {
        return false;
    }
    return true;
}

//��갴��
bool mousePress(const char* buttons) {

    uint8_t keyCode = mousueToKeyCode(buttons);
    if (keyCode == 0x00) {
        mousePressInfo = 0x00;
    }
    else {
        addMousePress(keyCode);
    }

    //wprintf(L"keyCode: 0x%02X\n", keyCode);


    MOUSE_INPUT_REPORT mouseData = { 0 };
    mouseData.ReportId = 2;
    mouseData.Buttons = keyCode;
    mouseData.DeltaX = 0;
    mouseData.DeltaY = 0;
    mouseData.WheelDelta = 0;

    if (!sendMouseReportToDriver(mouseData)) {
        return false;
    }
    return true;
}

//����ͷ�
bool mouseRelease(const char* buttons) {
    uint8_t keyCode = mousueToKeyCode(buttons);
    if (keyCode == 0) {
        mousePressInfo = 0;
    }
    else {
        removeMousePress(keyCode);
    }

    //wprintf(L"keyCode: 0x%02X\n", keyCode);


    MOUSE_INPUT_REPORT mouseData = { 0 };
    mouseData.ReportId = 2;
    mouseData.Buttons = 0;
    mouseData.DeltaX = 0;
    mouseData.DeltaY = 0;
    mouseData.WheelDelta = 0;

    if (!sendMouseReportToDriver(mouseData)) {
        return false;
    }
    return true;
}

//������
bool mouseWheel(char wheelDelta) {
    MOUSE_INPUT_REPORT mouseData = { 0 };
    mouseData.ReportId = 2;
    mouseData.Buttons = 0x80;
    mouseData.DeltaX = 0;
    mouseData.DeltaY = 0;
    mouseData.WheelDelta = wheelDelta;

    if (!sendMouseReportToDriver(mouseData)) {
        return false;
    }
    return true;
}

//�鿴���µİ���
bool checkPress() {
    bool hasKey = false;  // ����Ƿ��а���������
    int keyCount = 0;     // ��¼��������

    // ��ͳ���ж��ٸ���Ч����
    for (int i = 0; i < 6; i++) {
        if (keyboardPressInfo[i].button != NULL) {
            hasKey = true;
            keyCount++;
        }
    }

    // �����Ƿ��а��������ͬ����
    if (hasKey) {
        wprintf(L"���µİ�����");
        bool isFirst = true;
        for (int i = 0; i < 6; i++) {
            if (keyboardPressInfo[i].button != NULL) {
                if (!isFirst) {
                    wprintf(L",");  // ��������ö��ŷָ�
                }
                wprintf(L"%s", keyboardPressInfo[i].button);
                isFirst = false;
            }
        }
        wprintf(L"\n");
    }
    else {
        // û�а���ʱ�����ʾ
        wprintf(L"���̰���û�б�����\n");
    }

    wprintf(L"���η����� : 0x%02X\n", modifiersPressInfo);
    wprintf(L"��갴�� : 0x%02X\n", mousePressInfo);


    return true;
}






//���̼�������ʽ�棩
bool keyboardListenner(NEW_KEYBOARD_INFO keyboardInfoBox[]) {
    if (g_hDevice == INVALID_HANDLE_VALUE) {
        wprintf(L"�豸�����Ч���޷���ȡ��\n");
        return false;
    }

    KEYBOARD_INFO kbInfo = { 0 };
    DWORD dwBytesReturned = 0;
    int readCount = 0;
    int count = 0;

    while ((readCount == 0 || count < readCount) && !_kbhit()) {
        RtlZeroMemory(&kbInfo, sizeof(KEYBOARD_INFO));
        dwBytesReturned = 0;

        BOOL bRet = DeviceIoControl(
            g_hDevice,
            IOCTL_KeyboardListener,
            NULL,
            0,
            &kbInfo,
            sizeof(KEYBOARD_INFO),
            &dwBytesReturned,
            NULL
        );

        if (bRet && dwBytesReturned == sizeof(KEYBOARD_INFO)) {
            // ��ȡ�ɹ���װ������
            keyboardInfoBox[count].MakeCode = kbInfo.MakeCode;
            keyboardInfoBox[count].Button = ScancodeToButton(kbInfo.MakeCode);
            keyboardInfoBox[count].IsPress = kbInfo.IsPress ? L"����" : L"̧��";
            //wprintf(L"ɨ���룺%hhu��������%ls��״̬��%ls\n",
            //    keyboardInfoBox[count].MakeCode,
            //    keyboardInfoBox[count].Button,
            //    keyboardInfoBox[count].IsPress);
            count++;
        }
        else {
            DWORD dwErr = GetLastError();
            //�����˾ͷ���true��������ʱ��᷵��0û�б�����������bug�����þͲ����ޣ�
            if (dwErr == ERROR_NO_MORE_ITEMS || dwErr == 0) {
                //wprintf(L"�����������ݣ���ȡ���\n");
                return true;
            }
            // ��������ű���
            wprintf(L"��ȡʧ�ܣ�������: %d\n", dwErr);
            return false;
        }
    }

    if (_kbhit()) _getch();
    return true; // ���䷵��ֵ�����⺯��δ���巵��
}